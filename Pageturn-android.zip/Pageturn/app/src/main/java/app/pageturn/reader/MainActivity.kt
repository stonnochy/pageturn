package app.pageturn.reader

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewFeature
import kotlin.math.abs

/**
 * Hosts the Pageturn reader (assets/www/index.html) in a WebView.
 * The page is served from the app's own assets, so it works with no network and no permissions.
 * Controller buttons are turned into reader actions here, because that is more dependable than
 * the browser Gamepad API inside a WebView.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var chooserCallback: ValueCallback<Array<Uri>>? = null

    private val repeatable = setOf("left", "right", "up", "down", "minus", "plus")
    private var stickDir: String? = null
    private var stickNext = 0L

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        chooserCallback?.onReceiveValue(uris.toTypedArray())
        chooserCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true // needed for IndexedDB, where the library is stored
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(web.settings, false)
        }
        web.addJavascriptInterface(Bridge(), "PtNative")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == WebViewAssetLoader.DEFAULT_DOMAIN) return false
                if (u.scheme == "http" || u.scheme == "https" || u.scheme == "mailto") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                }
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                chooserCallback?.onReceiveValue(null)
                chooserCallback = callback
                picker.launch(arrayOf("application/epub+zip", "application/pdf", "application/octet-stream"))
                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.ptBack?window.ptBack():false") { r ->
                    if (r != "true") finish()
                }
            }
        })

        web.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/www/index.html")
    }

    private fun send(action: String) {
        web.evaluateJavascript("window.ptAct&&window.ptAct('$action')", null)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val action = when (e.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> "left"
            KeyEvent.KEYCODE_DPAD_RIGHT -> "right"
            KeyEvent.KEYCODE_DPAD_UP -> "up"
            KeyEvent.KEYCODE_DPAD_DOWN -> "down"
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_BUTTON_A -> "confirm"
            KeyEvent.KEYCODE_BUTTON_B -> "back"
            KeyEvent.KEYCODE_BUTTON_L1 -> "prevCh"
            KeyEvent.KEYCODE_BUTTON_R1 -> "nextCh"
            KeyEvent.KEYCODE_BUTTON_L2 -> "minus"
            KeyEvent.KEYCODE_BUTTON_R2 -> "plus"
            KeyEvent.KEYCODE_BUTTON_SELECT -> "settings"
            KeyEvent.KEYCODE_BUTTON_START -> "toc"
            else -> null
        } ?: return super.dispatchKeyEvent(e)

        if (e.action == KeyEvent.ACTION_DOWN && (e.repeatCount == 0 || action in repeatable)) send(action)
        return true
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        val isStick = (e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (isStick && e.action == MotionEvent.ACTION_MOVE) {
            val hx = e.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val x = if (abs(hx) > 0.5f) hx else e.getAxisValue(MotionEvent.AXIS_X)
            val y = if (abs(hy) > 0.5f) hy else e.getAxisValue(MotionEvent.AXIS_Y)
            val dir = when {
                x < -0.6f -> "left"
                x > 0.6f -> "right"
                y < -0.6f -> "up"
                y > 0.6f -> "down"
                else -> null
            }
            val now = SystemClock.uptimeMillis()
            if (dir == null) {
                stickDir = null
            } else if (dir != stickDir) {
                stickDir = dir; stickNext = now + 380; send(dir)
            } else if (now >= stickNext) {
                stickNext = now + 150; send(dir)
            }
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    /** Functions the page can call as window.PtNative.* */
    inner class Bridge {
        @JavascriptInterface
        fun keepAwake(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface
        fun immersive(on: Boolean) {
            runOnUiThread {
                val c = WindowCompat.getInsetsController(window, window.decorView)
                if (on) {
                    c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    c.hide(WindowInsetsCompat.Type.systemBars())
                } else {
                    c.show(WindowInsetsCompat.Type.systemBars())
                }
            }
        }
    }

    override fun onPause() {
        web.evaluateJavascript("window.ptSave&&window.ptSave()", null)
        web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
