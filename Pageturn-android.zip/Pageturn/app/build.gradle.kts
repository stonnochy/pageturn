plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.pageturn.reader"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.pageturn.reader"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
}

/*
 * The reader page needs JSZip, pdf.js and a few fonts. They are downloaded once at build time
 * into the app's assets, so the finished APK is fully offline and needs no INTERNET permission.
 */
val wwwLib = layout.projectDirectory.dir("src/main/assets/www/lib").asFile

val fetchWebAssets by tasks.registering {
    outputs.dir(wwwLib)
    outputs.upToDateWhen { false }
    doLast {
        val fontDir = File(wwwLib, "fonts")
        fontDir.mkdirs()

        fun download(url: String, target: File, required: Boolean): Boolean {
            if (target.exists() && target.length() > 0) return true
            return try {
                java.net.URL(url).openStream().use { input ->
                    target.outputStream().use { out -> input.copyTo(out) }
                }
                true
            } catch (e: Exception) {
                target.delete()
                if (required) throw GradleException("Could not download $url (${e.message}). Check your internet connection and build again.")
                logger.warn("Skipped optional file ${target.name}: ${e.message}")
                false
            }
        }

        val js = "https://cdn.jsdelivr.net/npm"
        download("$js/jszip@3.10.1/dist/jszip.min.js", File(wwwLib, "jszip.min.js"), true)
        download("$js/pdfjs-dist@3.11.174/build/pdf.min.js", File(wwwLib, "pdf.min.js"), true)
        download("$js/pdfjs-dist@3.11.174/build/pdf.worker.min.js", File(wwwLib, "pdf.worker.min.js"), true)

        // package id, CSS family name, variants
        val fonts = listOf(
            Triple("literata", "Literata", listOf("400-normal", "700-normal", "400-italic", "700-italic")),
            Triple("atkinson-hyperlegible", "Atkinson Hyperlegible", listOf("400-normal", "700-normal", "400-italic")),
            Triple("bricolage-grotesque", "Bricolage Grotesque", listOf("600-normal", "700-normal", "800-normal"))
        )
        val css = StringBuilder()
        for ((id, family, variants) in fonts) {
            for (v in variants) {
                val (weight, style) = v.split("-")
                val name = "$id-latin-$v.woff2"
                if (download("$js/@fontsource/$id@5/files/$name", File(fontDir, name), false)) {
                    css.append("@font-face{font-family:'$family';font-style:$style;font-weight:$weight;font-display:swap;src:url(fonts/$name) format('woff2')}\n")
                }
            }
        }
        File(wwwLib, "fonts.css").writeText(css.toString())
    }
}

tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(fetchWebAssets) }
